"""
Racecar :: A lightweight Bayesian sampling algorithm
"""
from __future__ import absolute_import
