# Racecar

This is a lightweight Bayesian sampling package.
